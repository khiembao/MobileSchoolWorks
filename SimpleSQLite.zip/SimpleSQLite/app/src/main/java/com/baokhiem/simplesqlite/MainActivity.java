package com.baokhiem.simplesqlite;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    EditText edt_name, edt_contact, edt_dateOfBirth;
    Button btn_insert, btn_update, btn_delete, btn_view;

    DBHelper db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        AnhXa();
        db = new DBHelper(this);

        btn_insert.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String nameTXT = edt_name.getText().toString();
                String contactTXT = edt_contact.getText().toString();
                String dobTXT = edt_dateOfBirth.getText().toString();

                Boolean checkInsertdata = db.insertUserDatabase(nameTXT, contactTXT, dobTXT);
                if (checkInsertdata ==  true)
                    Toast.makeText(MainActivity.this, "New Entry Inserted", Toast.LENGTH_SHORT).show();
                else
                    Toast.makeText(MainActivity.this, "No New Entry Inserted", Toast.LENGTH_SHORT).show();
            }


        });

        btn_update.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String nameTXT = edt_name.getText().toString();
                String contactTXT = edt_contact.getText().toString();
                String dobTXT = edt_dateOfBirth.getText().toString();

                Boolean checkUpdatedata = db.updateUserDatabase(nameTXT, contactTXT, dobTXT);
                if (checkUpdatedata ==  true)
                    Toast.makeText(MainActivity.this, "New Entry Updated", Toast.LENGTH_SHORT).show();
                else
                    Toast.makeText(MainActivity.this, "No New Entry Updated", Toast.LENGTH_SHORT).show();
            }


        });

        btn_delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String nameTXT = edt_name.getText().toString();

                Boolean checkDeletedata = db.deleteUserDatabase(nameTXT);
                if (checkDeletedata ==  true)
                    Toast.makeText(MainActivity.this, "Data Deleted", Toast.LENGTH_SHORT).show();
                else
                    Toast.makeText(MainActivity.this, "Data was not deleted", Toast.LENGTH_SHORT).show();
            }


        });
        btn_view.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Cursor res = db.getData();
                if (res.getCount()==0){
                    Toast.makeText(MainActivity.this, "Not found", Toast.LENGTH_SHORT).show();
                    return;
                }
                StringBuffer buffer = new StringBuffer();
                while(res.moveToNext()){
                    buffer.append("Name: "+ res.getString(0)+ "\n");
                    buffer.append("Contact: "+ res.getString(1)+ "\n");
                    buffer.append("Date of Birth: "+ res.getString(2)+ "\n");

                }

                AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
                builder.setCancelable(true);
                builder.setTitle("User Entries");
                builder.setMessage(buffer.toString());
                builder.show();
            }


        });
    }

    private void AnhXa(){
        edt_name = findViewById(R.id.edt_name);
        edt_contact = findViewById(R.id.edt_contact);
        edt_dateOfBirth = findViewById(R.id.edt_date);

        btn_insert = findViewById(R.id.btn_insert);
        btn_update = findViewById(R.id.btn_update);
        btn_delete = findViewById(R.id.btn_delete);
        btn_view = findViewById(R.id.btn_view);
    }
}