package com.baokhiem.bth03_maytinhcoban;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import org.mozilla.javascript.Context;
import org.mozilla.javascript.Scriptable;

public class MainActivity extends AppCompatActivity {
    Button btnClear, btnNgoac, btnPercent, btnPlus, btn7, btn8,btn9, btnMulti,
            btn4, btn6,btn5,btnMinus,btn1, btn2, btn3,
            btnDivide, btn0, btnDot, btnEqual;
    TextView tv_input, tv_result;
    String process;

    Boolean checkBracket = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btn0 = findViewById(R.id.btn_0);
        btn1 = findViewById(R.id.btn_1);
        btn2 = findViewById(R.id.btn_2);
        btn3 = findViewById(R.id.btn_3);
        btn4 = findViewById(R.id.btn_4);
        btn5 = findViewById(R.id.btn_5);
        btn6 = findViewById(R.id.btn_6);
        btn7 = findViewById(R.id.btn_7);
        btn8 = findViewById(R.id.btn_8);
        btn9 = findViewById(R.id.btn_9);

        btnMinus = findViewById(R.id.btn_Minus);
        btnPlus = findViewById(R.id.btn_Plus);
        btnDivide = findViewById(R.id.btn_Divide);
        btnMulti = findViewById(R.id.btn_Multiply);
        btnEqual = findViewById(R.id.btn_Equals);

        btnDot = findViewById(R.id.btn_Dot);
        btnClear = findViewById(R.id.btn_Clear);
        btnPercent = findViewById(R.id.btn_Percent);
        btnNgoac = findViewById(R.id.btn_Ngoac);

        tv_input = findViewById(R.id.tv_input);
        tv_result = findViewById(R.id.tv_result);

        btnClear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                tv_input.setText("");
                tv_result.setText("");
            }
        });


        btn0.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                process = tv_input.getText().toString();
                tv_input.setText(process + "0");
            }
        });
        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                process = tv_input.getText().toString();
                tv_input.setText(process + "1");
            }
        });
        btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                process = tv_input.getText().toString();
                tv_input.setText(process + "2");
            }
        });
        btn3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                process = tv_input.getText().toString();
                tv_input.setText(process + "3");
            }
        });
        btn4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                process = tv_input.getText().toString();
                tv_input.setText(process + "4");
            }
        });
        btn5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                process = tv_input.getText().toString();
                tv_input.setText(process + "5");
            }
        });
        btn6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                process = tv_input.getText().toString();
                tv_input.setText(process + "6");
            }
        });
        btn7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                process = tv_input.getText().toString();
                tv_input.setText(process + "7");
            }
        });
        btn8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                process = tv_input.getText().toString();
                tv_input.setText(process + "8");
            }
        });
        btn9.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                process = tv_input.getText().toString();
                tv_input.setText(process + "9");
            }
        });
        btnPlus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                process = tv_input.getText().toString();
                tv_input.setText(process + "+");
            }
        });
        btnMinus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                process = tv_input.getText().toString();
                tv_input.setText(process + "-");
            }
        });
        btnMulti.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                process = tv_input.getText().toString();
                tv_input.setText(process + "x");
            }
        });
        btnDivide.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                process = tv_input.getText().toString();
                tv_input.setText(process + "/");
            }
        });
        btnDot.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                process = tv_input.getText().toString();
                tv_input.setText(process + ".");
            }
        });
        btnPercent.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                process = tv_input.getText().toString();
                tv_input.setText(process + "%");
            }
        });
        btnNgoac.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (checkBracket){
                    process = tv_input.getText().toString();
                    tv_input.setText(process + ")");
                    checkBracket = false;
                } else {
                    process = tv_input.getText().toString();
                    tv_input.setText(process + ")");
                    checkBracket = true;
                }
            }
        });

        btnEqual.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                process = tv_input.getText().toString();

                process = process.replaceAll("x", "*");
                process = process.replaceAll("%", "/100");
                Context rhino = Context.enter();
                rhino.setOptimizationLevel(-1);
                String finalResult = "";
                try{
                    Scriptable scriptable = rhino.initStandardObjects();
                    finalResult = rhino.evaluateString(scriptable, process, "javascript", 1, null).toString();
                } catch (Exception e){
                    finalResult = "0";
                }

                tv_result.setText(finalResult);
            }

        });

    }
}