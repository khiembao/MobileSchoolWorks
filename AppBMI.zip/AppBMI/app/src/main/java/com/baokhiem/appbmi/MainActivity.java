package com.baokhiem.appbmi;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    EditText etChieuCao, etCanNang;
    RadioButton rdNam, rdNu;
    Button btnTinhBMI;
    TextView txtChiSo, txtNhanXet;
    double chiSo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        etChieuCao = findViewById(R.id.et_chieuCao);
        etCanNang = findViewById(R.id.et_canNang);
        rdNam = findViewById(R.id.rd_nam);
        rdNu = findViewById(R.id.rd_nu);
        btnTinhBMI = findViewById(R.id.btn_tinh);
        txtChiSo = findViewById(R.id.txt_ketQua);
        txtNhanXet = findViewById(R.id.txt_nhanXet);

        btnTinhBMI.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                double chieuCao = Double.parseDouble(etChieuCao.getText().toString())/100;
                double canNang = Double.parseDouble(etCanNang.getText().toString());
                chiSo = Math.round((canNang/Math.pow(chieuCao,2))*10.0)/10.0;
                if (rdNam.isChecked()){
                    if(chiSo < 18.5){
                        txtChiSo.setText(String.valueOf(chiSo));
                        txtNhanXet.setText("Bạn cần bổ sung thêm dinh dưỡng");
                    }else if(chiSo >= 18.5 && chiSo <= 24.9){
                        txtChiSo.setText(String.valueOf(chiSo));
                        txtNhanXet.setText("Bạn có chỉ số BMI bình thường");
                    } else if(chiSo == 25){
                        txtChiSo.setText(String.valueOf(chiSo));
                        txtNhanXet.setText("Bạn đang bị thừa cân");
                    }else if(chiSo > 25 && chiSo <= 29.9){
                        txtChiSo.setText(String.valueOf(chiSo));
                        txtNhanXet.setText("Bạn đang ở giai đoạn tiền béo phì");
                    }else if(chiSo >=30  && chiSo <= 34.9){
                        txtChiSo.setText(String.valueOf(chiSo));
                        txtNhanXet.setText("Bạn đang ở béo phì mức độ I");
                    }else if(chiSo >=35  && chiSo <= 39.9){
                        txtChiSo.setText(String.valueOf(chiSo));
                        txtNhanXet.setText("Bạn đang ở béo phì mức độ II");
                    }else if(chiSo == 40){
                        txtChiSo.setText(String.valueOf(chiSo));
                        txtNhanXet.setText("Bạn đang ở béo phì mức độ III");
                    }
                }
                else if (rdNu.isChecked()){
                    if(chiSo < 18.5){
                        txtChiSo.setText(String.valueOf(chiSo));
                        txtNhanXet.setText("Bạn cần bổ sung thêm dinh dưỡng");
                    }else if(chiSo >= 18.5 && chiSo <= 22.9){
                        txtChiSo.setText(String.valueOf(chiSo));
                        txtNhanXet.setText("Bạn có chỉ số BMI bình thường");
                    } else if(chiSo == 23){
                        txtChiSo.setText(String.valueOf(chiSo));
                        txtNhanXet.setText("Bạn đang bị thừa cân");
                    }else if(chiSo > 23 && chiSo <= 24.9){
                        txtChiSo.setText(String.valueOf(chiSo));
                        txtNhanXet.setText("Bạn đang ở giai đoạn tiền béo phì");
                    }else if(chiSo >=25 && chiSo <= 29.9){
                        txtChiSo.setText(String.valueOf(chiSo));
                        txtNhanXet.setText("Bạn đang ở béo phì mức độ I");
                    }else if(chiSo >=30  && chiSo <= 39.9){
                        txtChiSo.setText(String.valueOf(chiSo));
                        txtNhanXet.setText("Bạn đang ở béo phì mức độ II");
                    }else if(chiSo == 40){
                        txtChiSo.setText(String.valueOf(chiSo));
                        txtNhanXet.setText("Bạn đang ở béo phì mức độ III");
                    }
                }
                else{
                    Toast.makeText(getApplicationContext(), "Vui lòng chọn giới tính", Toast.LENGTH_LONG).show();
                }
            }
        });
    }
}