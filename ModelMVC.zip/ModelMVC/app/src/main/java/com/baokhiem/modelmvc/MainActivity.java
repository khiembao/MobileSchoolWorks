package com.baokhiem.modelmvc;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private EditText edt_email, edt_password;
    private Button btn_login;
    private TextView tv_msg;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        AnhXa();

        btn_login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                clickLogin();
            }
        });
    }

    private void AnhXa(){
        edt_email = findViewById(R.id.edt_email);
        edt_password = findViewById(R.id.edt_password);

        tv_msg = findViewById(R.id.tv_msg);

        btn_login = findViewById(R.id.btn_login);

    }

    private void clickLogin(){
        String strEmail = edt_email.getText().toString().trim();
        String strPassword = edt_password.getText().toString().trim();

        User user = new User(strEmail, strPassword);

        if(user.isValidEmail() && user.isValidPassword())
        {
            tv_msg.setText("LOGIN SUCCESS");
        } else {
            tv_msg.setText("Email or Password invalid");
        }
    }
}