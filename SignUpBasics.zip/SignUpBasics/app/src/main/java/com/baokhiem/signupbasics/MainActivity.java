package com.baokhiem.signupbasics;

import static com.basgeekball.awesomevalidation.ValidationStyle.BASIC;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.basgeekball.awesomevalidation.AwesomeValidation;
import com.basgeekball.awesomevalidation.utility.RegexTemplate;

public class MainActivity extends AppCompatActivity {

    EditText edt_name, edt_email, edt_pass, edt_phone;
    Button btn_check;

    AwesomeValidation awesomeValidation;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        awesomeValidation = new AwesomeValidation(BASIC);
        AnhXa();
        String regexPassword = "(?=.*[a-z])(?=.*[A-Z])(?=.*[\\d])"
                +"(?=.*[~`!@#\\$%\\^&\\*\\(\\)\\-_\\+"
                +"=\\{\\}\\[\\]\\|\\;:\"<>,./\\?]).{8,}";
        awesomeValidation.addValidation(MainActivity.this,R.id.edt_name,"[a-zA-Z\\s]+",R.string.err_name);
        awesomeValidation.addValidation(MainActivity.this, R.id.edt_phone, RegexTemplate.TELEPHONE, R.string.err_tel);
        awesomeValidation.addValidation(MainActivity.this, R.id.edt_email, Patterns.EMAIL_ADDRESS, R.string.err_email);
        awesomeValidation.addValidation(MainActivity.this, R.id.edt_pass, regexPassword,R.string.err_password);

        btn_check.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                    if (awesomeValidation.validate()) {
                        String name = edt_name.getText().toString();
                        String email = edt_email.getText().toString();
                        String pass = edt_pass.getText().toString();
                        String phone = edt_phone.getText().toString();
                    } else{
                        Toast.makeText(getApplicationContext(), "Everything is fine", Toast.LENGTH_SHORT).show();
                    }

            }
        });


    }

    private void AnhXa(){
        edt_name = findViewById(R.id.edt_name);
        edt_email = findViewById(R.id.edt_email);
        edt_pass = findViewById(R.id.edt_pass);
        edt_phone = findViewById(R.id.edt_phone);

        btn_check = findViewById(R.id.btn_check);
    }
}